#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

# Define the joint positions
joint_positions = [0.0, 0.0, 0.0, 0.0]

# Define the increments for each joint movement
increment = 0.1

def callback(data):
    global joint_positions
    
    # Update joint positions based on the Twist message
    if data.angular.z == 1:  # j pressed
        joint_positions[0] -= increment
    elif data.angular.z == -1:  # l pressed
        joint_positions[0] += increment
    elif data.linear.x == 1:  # i pressed
        joint_positions[1] += increment
    elif data.linear.x == -1:  # m pressed
        joint_positions[1] -= increment
    elif data.linear.z == 1:  # u pressed
        joint_positions[2] += increment
    elif data.linear.z == -1:  # o pressed
        joint_positions[2] -= increment
    elif data.linear.y == 1:  # , pressed
        joint_positions[3] += increment
    elif data.linear.y == -1:  # . pressed
        joint_positions[3] -= increment
    
    # Print joint positions
    rospy.loginfo("Positions: rev1: %.2f, rev2: %.2f, rev3: %.2f, rev4: %.2f" % (joint_positions[0], joint_positions[1], joint_positions[2], joint_positions[3]))
    
    traj_msg = JointTrajectory()
    traj_msg.joint_names = ['rev1', 'rev2', 'rev3', 'rev4']
    
    point = JointTrajectoryPoint()
    point.positions = joint_positions
    point.time_from_start = rospy.Duration(1.0)

    traj_msg.points.append(point)
    pub.publish(traj_msg)

if __name__ == '__main__':
    rospy.init_node('teleop_to_joint_trajectory')
    pub = rospy.Publisher('/manipulator_controller/command', JointTrajectory, queue_size=10)
    rospy.Subscriber('/cmd_vel', Twist, callback)
    rospy.spin()

